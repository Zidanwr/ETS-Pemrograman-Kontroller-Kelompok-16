/*
 * Smart Room Controller - ESP32-S3
 * Output CSV ke Serial untuk GNUPlot
 *
 * Format output (CSV):
 *   timestamp_ms,ldr_value,pir,led,servo_angle
 *
 * Komponen:
 *   - PIR Sensor  → GPIO4  (deteksi gerak)
 *   - LDR Sensor  → GPIO1  (sensor cahaya, ADC)
 *   - LED Ruangan → GPIO2  (lampu ruangan)
 *   - Servo Motor → GPIO7  (kontrol pintu/tirai)
 */

#include <ESP32Servo.h>

// ── Pin Definitions ──────────────────────────────────────────
#define PIN_PIR       4
#define PIN_LDR       1
#define PIN_LED       2
#define PIN_SERVO     7

// ── Threshold & Timing ───────────────────────────────────────
#define LDR_THRESHOLD     2000
#define PIR_HOLD_TIME     5000
#define LOG_INTERVAL      500    // Log CSV setiap 500ms

// ── Servo Positions ──────────────────────────────────────────
#define SERVO_OPEN        90
#define SERVO_CLOSED      0

// ── Global Variables ─────────────────────────────────────────
Servo myServo;

bool          ledState       = false;
bool          servoOpen      = false;
int           servoAngle     = 0;
unsigned long lastMotionTime = 0;
unsigned long lastLogTime    = 0;

// ── Setup ─────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  myServo.attach(PIN_SERVO, 500, 2400);
  myServo.write(SERVO_CLOSED);
  servoAngle = SERVO_CLOSED;
  delay(500);

  // Header CSV — GNUPlot akan skip baris yang diawali '#'
  Serial.println("# Smart Room Controller - Data Log");
  Serial.println("# timestamp_ms,ldr_value,pir,led,servo_angle");
}

// ── Loop ──────────────────────────────────────────────────────
void loop() {
  bool          motionDetected = digitalRead(PIN_PIR);
  int           ldrValue       = analogRead(PIN_LDR);
  bool          isDark         = (ldrValue < LDR_THRESHOLD);
  unsigned long now            = millis();

  // Update waktu gerak terakhir
  if (motionDetected) {
    lastMotionTime = now;
  }

  bool recentMotion = (now - lastMotionTime < PIR_HOLD_TIME);

  // Kontrol LED
  bool shouldLedOn = isDark && recentMotion;
  if (shouldLedOn != ledState) {
    ledState = shouldLedOn;
    digitalWrite(PIN_LED, ledState ? HIGH : LOW);
  }

  // Kontrol Servo
  bool shouldServoOpen = recentMotion;
  if (shouldServoOpen != servoOpen) {
    servoOpen  = shouldServoOpen;
    servoAngle = servoOpen ? SERVO_OPEN : SERVO_CLOSED;
    myServo.write(servoAngle);
  }

  // Output CSV setiap LOG_INTERVAL ms
  if (now - lastLogTime >= LOG_INTERVAL) {
    lastLogTime = now;
    // Format: timestamp_ms,ldr_value,pir,led,servo_angle
    Serial.print(now);
    Serial.print(",");
    Serial.print(ldrValue);
    Serial.print(",");
    Serial.print(motionDetected ? 1 : 0);
    Serial.print(",");
    Serial.print(ledState ? 1 : 0);
    Serial.print(",");
    Serial.println(servoAngle);
  }
}
